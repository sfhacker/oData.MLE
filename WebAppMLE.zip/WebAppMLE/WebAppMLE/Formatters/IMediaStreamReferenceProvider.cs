﻿
namespace WebAppMLE.Formatters
{
    using System;
    using System.Web.OData;
    using Microsoft.OData.Core;
    public interface IMediaStreamReferenceProvider
    {
        ODataStreamReferenceValue GetMediaStreamReference(EntityInstanceContext entity, Uri baseUri);
    }
}