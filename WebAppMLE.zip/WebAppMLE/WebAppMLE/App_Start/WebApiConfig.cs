﻿
namespace WebAppMLE.App_Start
{
    using Formatters;
    using Microsoft.OData.Edm;
    using Models;
    using System.Linq;
    using System.Net.Http.Formatting;
    using System.Web.Http;
    using System.Web.OData.Builder;
    using System.Web.OData.Extensions;
    using System.Web.OData.Formatter;
    using System.Web.OData.Formatter.Deserialization;

    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            RegisterMediaEntity(config, GlobalConfiguration.DefaultServer);

            config.Formatters.Clear();
            config.Formatters.InsertRange(0, ODataMediaTypeFormatters.Create(new MediaEntitySerializerProvider(), new DefaultODataDeserializerProvider()));
            config.Formatters.Add(new JsonMediaTypeFormatter());   //Enable JSON in the web service

            config.EnsureInitialized();
        }

        public static void RegisterMediaEntity(HttpConfiguration config, HttpServer server)
        {
            config.IncludeErrorDetailPolicy = IncludeErrorDetailPolicy.Always;

            config.EnableAlternateKeys(true);

            config.MapODataServiceRoute(routeName: "odata route", routePrefix: "odata", model: GetEdmModel());

            //config.  MapRestierRoute<MediaEntityApi>(
            //    "MediaEntityApi", "api/mediaentity",
            //    new RestierBatchHandler(server));
        }
        private static IEdmModel GetEdmModel()
        {
            var builder = new ODataConventionModelBuilder();

            builder.EntitySet<Person>("People");
            builder.EntitySet<Photo>("Photos");
            var entityConfiguration = builder.StructuralTypes.First(t => t.ClrType == typeof(Photo));
            entityConfiguration.AddProperty(typeof(Photo).GetProperty("Smallpreview"));

            return builder.GetEdmModel();
        }
    }
}