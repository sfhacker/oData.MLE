﻿
namespace WebAppMLE.Controllers
{
    using Models;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Specialized;
    using System.IO;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.Http;
    using System.Web.OData;
    public class PeopleController : ODataController
    {
        private static readonly DirectoryInfo _appDataDirectory = new DirectoryInfo(AppDomain.CurrentDomain.GetData("DataDirectory").ToString());
        private static readonly DirectoryInfo _filesDirectory = new DirectoryInfo(Path.Combine(_appDataDirectory.FullName, "Files"));

        [HttpGet]
        public IHttpActionResult Get()
        {
            return Ok();
        }

        [HttpGet]
        public IHttpActionResult Get([FromODataUri] string key)
        {
            return Ok();
        }

        // Person person
        // IHttpActionResult
        [HttpPost]
        public async Task<HttpResponseMessage> Post()
        {
            if (!Request.Content.IsMimeMultipartContent())
            {
                // if JSon only
                // if Image only
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            string root = HttpContext.Current.Server.MapPath("~/App_Data");

            var streamProvider = new MultipartFormDataStreamProvider(root);
            await Request.Content.ReadAsMultipartAsync(streamProvider);
            foreach (MultipartFileData fileData in streamProvider.FileData)
            {
                if (string.IsNullOrEmpty(fileData.Headers.ContentDisposition.FileName))
                {
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable, "This request is not properly formatted");
                }
                string fileName = fileData.Headers.ContentDisposition.FileName;
                if (fileName.StartsWith("\"") && fileName.EndsWith("\""))
                {
                    fileName = fileName.Trim('"');
                }
                if (fileName.Contains(@"/") || fileName.Contains(@"\"))
                {
                    fileName = Path.GetFileName(fileName);
                }
                //File.Copy(fileData.LocalFileName, Path.Combine(_filesDirectory.FullName, fileName), true);
                File.Move(fileData.LocalFileName, Path.Combine(_filesDirectory.FullName, fileName));
            }

            if (streamProvider.FormData != null)
            {
                string[] value = streamProvider.FormData.GetValues("json");

                string jsonValue = string.Join("", value);
                if (!string.IsNullOrEmpty(jsonValue))
                {
                    Person account = JsonConvert.DeserializeObject<Person>(jsonValue);
                }
            }
            //foreach (NameValueCollection item in streamProvider.FormData)     //  Contents
            //{
            //    string contentName = item.  Headers.ContentDisposition.Name;
                
            //    if (!string.IsNullOrEmpty(contentName))
            //    {
            //        if (contentName.StartsWith("\"") && contentName.EndsWith("\""))
            //        {
            //            contentName = contentName.Trim('"');
            //        }
            //        if (contentName.Equals("json"))
            //        {
            //            string json = item.ReadAsStringAsync().Result;
            //        }
            //    }
            //}
            //return NotFound();
            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}