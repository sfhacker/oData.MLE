﻿
namespace WebAppMLE.Models
{
    using System.ComponentModel.DataAnnotations.Schema;
    using System.IO;
    using System.Web.OData.Builder;

    // Mark the entity to have stream
    // The photo stream is stored in file system, it could be stored in database as byte array too.
    // This implies a no-named property for stream and conversion url to access is ~/entityset(key)/$value
    [MediaType]
    public class Photo
    {
        public string Id { get; set; }

        public long Size { get; set; }

        public string Name { set; get; }

        public string Type { set; get; }

        // Will not be a database column but an Edm model property
        // The stream data is stored in filesystem but not database.
        [NotMapped]
        public Stream Smallpreview { get; set; }
    }
}