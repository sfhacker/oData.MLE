﻿/// <summary>
/// https://dotnetcodr.com/2013/01/10/how-to-post-a-multipart-http-message-to-a-web-service-in-c-and-handle-it-with-java/
/// </summary>
namespace ConsoleApplication2
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class Program
    {
        private const string MEDIA_TYPE_JSON = "application/json";

        private const string PHOTO_JSON = "{ \"Id\": \"1234-abcd-9876\", \"Size\": 123456, \"Name\": \"File1.pdf\" }";

        static void Main(string[] args)
        {
            Sending_Person(@"D:\Backup-VS-2017-07-29\EIV_Demo-2017.pdf");

            // Sending_same_content_multiple_times(@"D:\Backup-VS-2017-07-29\EIV_Demo-2017.pdf");

            //SendFileToServer(@"D:\Backup-VS-2017-07-29\EIV_Demo-2017.pdf");

            Console.WriteLine("Waiting ...");
            Console.ReadLine();
        }

        private static HttpContent PrepareBody(string reqContent)
        {
            HttpContent postContent = null;

            // By default, Content-Disposition is null
            postContent = new StringContent(reqContent, System.Text.Encoding.UTF8, MEDIA_TYPE_JSON);
            postContent.Headers.Add("Content-Disposition", "form-data; name=\"json\"");

            return postContent;
        }

        // StreamContent
        // ByteArrayContent
        private static StreamContent PrepareAttachment(string fileFullPath)
        {
            if (string.IsNullOrEmpty(fileFullPath))
            {
                return null;
            }
            bool rst = File.Exists(fileFullPath);
            if (!rst)
            {
                return null;
            }

            FileStream fs = File.OpenRead(fileFullPath);
            if (fs.Length < 1)
            {
                fs.Close();
                fs.Dispose();

                return null;
            }
            fs.Position = 0;

            StreamContent streamContent = new StreamContent(fs);
            streamContent.Headers.Add("Content-Type", "application/octet-stream");
            streamContent.Headers.Add("Content-Disposition", "form-data; name=\"file\"; filename=\"" + Path.GetFileName(fileFullPath) + "\"");
            //streamContent.Headers.Add("Content-Disposition", "form-data; name=\"file\"");

            //MemoryStream ms = new MemoryStream();

            //fs.CopyTo(ms);

            //var imageContent = new ByteArrayContent(ms.ToArray());
            //imageContent.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");

            // ?????
            // fs.Close();
            // fs.Dispose();

            return streamContent;
            //return imageContent;

        }
        private static void SendFileToServer(string fileFullPath)
        {
            FileInfo fi = new FileInfo(fileFullPath);
            string fileName = fi.Name;
            byte[] fileContents = File.ReadAllBytes(fi.FullName);
            Uri webService = new Uri(@"http://localhost:51472/odata/Photos");
            HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, webService);
            requestMessage.Headers.ExpectContinue = false;

            // OK
            MultipartFormDataContent multiPartContent = new MultipartFormDataContent("----MyGreatBoundary");
            // MultipartContent multiPartContent = new MultipartContent("mixed");

            ByteArrayContent byteArrayContent = new ByteArrayContent(fileContents);
            // byteArrayContent.Headers.Add("Content-Type", "application/octet-stream");
            byteArrayContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
            byteArrayContent.Headers.ContentLength = fileContents.Length;

            multiPartContent.Add(byteArrayContent);

            //multiPartContent.Add(byteArrayContent, "this is the name of the content", fileName);

            //multiPartContent.Add(PrepareBody(PHOTO_JSON), "json");
            ////multiPartContent.Add(PrepareBody(PHOTO_JSON));
            //multiPartContent.Add(PrepareAttachment(fileFullPath), "file", Path.GetFileName(fileFullPath));
            ////multiPartContent.Add(PrepareAttachment(fileFullPath));

            requestMessage.Content = multiPartContent;  // PrepareBody(PHOTO_JSON);   // PrepareBody(PHOTO_JSON);            // multiPartContent;

            HttpClient httpClient = new HttpClient();
            try
            {
                Task<HttpResponseMessage> httpRequest = httpClient.SendAsync(requestMessage, HttpCompletionOption.ResponseContentRead, CancellationToken.None);

                HttpResponseMessage httpResponse = httpRequest.Result;

                HttpContent responseContent = httpResponse.Content;

                if (responseContent != null)
                {
                    Task<String> stringContentsTask = responseContent.ReadAsStringAsync();
                    String stringContents = stringContentsTask.Result;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static async Task Sending_same_content_multiple_times(string fileFullPath)
        {
            Uri webService = new Uri(@"http://localhost:51472/odata/");

            var client = new HttpClient { BaseAddress = webService };

            FileInfo fi = new FileInfo(fileFullPath);
            string fileName = fi.Name;
            byte[] fileContents = File.ReadAllBytes(fi.FullName);

            //var stream = new MemoryStream();
            //var sw = new StreamWriter(stream);
            //sw.Write("This is a stream");
            //sw.Flush();
            //fs.CopyTo(ms);
            //stream.Position = 0;

            //StreamContent sc = new StreamContent(stream);
            //sc.Headers.Add("Content-Type", "application/octet-stream");
            ////byteArrayContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
            //sc.Headers.Add("Content-Disposition", "form-data; name=\"file\"; filename=\"" + Path.GetFileName(fileFullPath) + "\"");

            // DOES NOT WORK when reaching the server!!!!
            //ByteArrayContent bc = new ByteArrayContent(fileContents);

            MemoryStream stream = new MemoryStream();
            FileStream file = new FileStream(fileFullPath, FileMode.Open, FileAccess.Read);
            file.CopyTo(stream);
            stream.Position = 0;

            StreamContent sc = new StreamContent(stream);
            sc.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            sc.Headers.Add("Content-Disposition", "form-data; name=\"file\"; filename=\"" + Path.GetFileName(fileFullPath) + "\"");

            ByteArrayContent byteArrayContent = new ByteArrayContent(fileContents);
            // byteArrayContent.Headers.Add("Content-Type", "application/octet-stream");
            byteArrayContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
            byteArrayContent.Headers.ContentLength = fileContents.Length;
            byteArrayContent.Headers.Add("Content-Disposition", "form-data; name=\"file\"; filename=\"" + Path.GetFileName(fileFullPath) + "\"");
            //byteArrayContent.Headers.Add("Content-Disposition", "form-data; name=\"file\"");

            StringContent json = new StringContent("This string will be sent repeatedly", System.Text.Encoding.UTF8, MEDIA_TYPE_JSON);
            FormUrlEncodedContent urlForm = new FormUrlEncodedContent(new[] { new KeyValuePair<string, string>("foo", "bar"), });

            var multipart = new MultipartFormDataContent("---- EIV.Financiero / 2017 ----")
        {
            PrepareBody(PHOTO_JSON), //json,
            urlForm,
            byteArrayContent   // PrepareAttachment(fileFullPath) // sc
        };

            //var content = new ReusableContent(multipart);

            // Photos
            // content
            var response = await client.PostAsync(@"http://localhost:51472/odata/People", multipart);
            response.EnsureSuccessStatusCode();
        }

        public static void Sending_Person(string fileFullPath)
        {
            Uri webService = new Uri(@"http://localhost:51472/odata/");

            var client = new HttpClient { BaseAddress = webService };

            FileInfo fi = new FileInfo(fileFullPath);
            string fileName = fi.Name;
            byte[] fileContents = File.ReadAllBytes(fi.FullName);

            // StreamContent sc = PrepareAttachment(fileFullPath);
            ByteArrayContent byteArrayContent = new ByteArrayContent(fileContents);
            // byteArrayContent.Headers.Add("Content-Type", "application/octet-stream");
            byteArrayContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
            byteArrayContent.Headers.ContentLength = fileContents.Length;
            byteArrayContent.Headers.Add("Content-Disposition", "form-data; name=\"file\"; filename=\"" + Path.GetFileName(fileFullPath) + "\"");

            Person testPerson = new Person()
            {
                PersonId = 123,
                Photo = new Photo()
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = "One.pdf",
                    Size = 390202
                }
            };

            var content = new MultipartFormDataContent();

            var stringContent = new StringContent(JsonConvert.SerializeObject(testPerson));
            stringContent.Headers.Add("Content-Disposition", "form-data; name=\"json\"");
            content.Add(stringContent, "json");

            //content.Add(sc, "file", fileFullPath);
            content.Add(byteArrayContent, "file", fileFullPath);

            // Photos
            // content
            var response = client.PostAsync(@"http://localhost:51472/odata/People", content).Result;
            response.EnsureSuccessStatusCode();
        }
    }

    public sealed class Person
    {
        public long PersonId { get; set; }

        public string UserName { get; set; }

        public Photo Photo { get; set; }

        // A non-media entity type could have stream properties, and its value should be set to ODataStreamReferenceValue
        // when requesting Person
        public Stream StreamMedia { get; set; }
    }

    public sealed class Photo
    {
        public string Id { get; set; }

        public long Size { get; set; }

        public string Name { set; get; }

        public string Type { set; get; }
    }

    public class ReusableContent : HttpContent
    {
        private readonly HttpContent _innerContent;

        public ReusableContent(HttpContent innerContent)
        {
            _innerContent = innerContent;
        }

        protected override async Task SerializeToStreamAsync(Stream stream, TransportContext context)
        {
            await _innerContent.CopyToAsync(stream);
        }

        protected override bool TryComputeLength(out long length)
        {
            length = -1;
            return false;
        }

        protected override void Dispose(bool disposing)
        {
            // Don't call base dispose
            //base.Dispose(disposing);
        }
    }
}