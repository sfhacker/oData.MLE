﻿
namespace WebAppMLE.Controllers
{
    using Formatters;
    using Models;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Controllers;
    using System.Web.OData;
    using System.Web.OData.Routing;

    /// <summary>
    /// For photo, the metadata information is stored in database.
    /// The real photo file is stored in file system
    /// The method without value will operate with metadata.
    /// The method with value will operate with photo stream.
    ///  </summary>
    public class PhotosController : ODataController
    {
        private PhotoDataStoreAccess _photoDataStoreAccess = null;

        private PhotoDataStoreAccess PhotoDataStoreAccess
        {
            get
            {
                if (this._photoDataStoreAccess == null)
                {
                    this._photoDataStoreAccess = new PhotoDataStoreAccess();
                }
                return this._photoDataStoreAccess;
            }
        }

        public IHttpActionResult Get()
        {
            return Ok();
        }

        [HttpGet]
        public IHttpActionResult Get([FromODataUri] string key)
        {
            return Ok();
        }

        // Works fine if only JSon in the body!
        // Works fine if JSon + Image in the body!
        // Works fine if only Image in the body!
        // Post([FromBody]Photo photo) : DOES NOT WORK!!!!
        [HttpPost]
        public IHttpActionResult Post()
        {
            // Check if the request contains multipart/form-data.
            if (!Request.Content.IsMimeMultipartContent())
            {
                //var testOne = Request.Content.ReadAsFormDataAsync().Result;
                var testOne = Request.Content.ReadAsStreamAsync().Result;

                // if JSon only
                // if Image only
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }
            if (!Request.Content.Headers.ContentLength.HasValue || Request.Content.Headers.ContentLength.Value <= 0)
            {
                return BadRequest();
            }

            var contentTypeHeader = Request.Content.Headers.ContentType;

            if (contentTypeHeader == null || contentTypeHeader.MediaType == null)
            {
                return BadRequest();
            }

            var contentLength = Request.Content.Headers.ContentLength;

            if (contentLength.Value <= 0)
            {
                return BadRequest();
            }

            //  WORKING NOW
            //string root = HttpContext.Current.Server.MapPath("~/App_Data");
            //var provider = new MultipartFormDataStreamProvider(root);
            //var task = Request.Content.ReadAsMultipartAsync(provider).ContinueWith(t =>
            //{
            //    if (t.IsFaulted || t.IsCanceled)
            //        throw new HttpResponseException(HttpStatusCode.InternalServerError);
            //});

            // NO
            var provider = Request.Content.ReadAsMultipartAsync().Result;
            //var testHereBis = Request.Content.ReadAsMultipartAsync(provider).Result;

            //// Only one
            //var fileDataCount = provider.FileData.Count;

            //// Two
            //var contentCount = provider.Contents.Count;

            //// Zero
            //var formDataCount = provider.FormData.Count;

            //HttpContent reqContent = Request.Content;

            //foreach (MultipartFileData file in provider.FileData)
            //{
            //    var one = file.Headers.ContentDisposition.FileName;

            //    var testOne = file.Headers.ContentDisposition.Name;
            //    var testTwo = file.Headers.ContentDisposition.Size;

            //    // Cannot access a disposed object. Object name: 'System.Net.Http.StringContent'.
            //    //var fileSize = file.Headers.ContentLength;    // Error
            //    var two = file.LocalFileName;

            //    string fileName = file.Headers.ContentDisposition.FileName;
            //    if (fileName.StartsWith("\"") && fileName.EndsWith("\""))
            //    {
            //        fileName = fileName.Trim('"');
            //    }
            //    if (fileName.Contains(@"/") || fileName.Contains(@"\"))
            //    {
            //        fileName = Path.GetFileName(fileName);
            //    }
            //    //File.Move(file.LocalFileName, Path.Combine(@"D:\EIVA\Temp_file.pdf", fileName));
            //}

            //var filePart = provider.Contents.Where(x => x.Headers.ContentDisposition.Name.Replace("\"", string.Empty) == "file" && x.Headers.ContentDisposition.FileName != null).Single();
            //var filePart = provider.Contents.Where(x => x.Headers.ContentDisposition.Name != null && x.Headers.ContentDisposition.Name.Replace("\"", string.Empty) == "file").SingleOrDefault();

            //if (filePart != null)
            //{
            //    Stream streamFile = filePart.ReadAsStreamAsync().Result;
            //}
            // if i do this before 'ReadAsMultipartAsync()' it works!!!
            var streamNew = Request.Content.ReadAsStreamAsync().Result;

            // it works if we do not send a file!!!!
            
            //var provider = Request.Content.ReadAsMultipartAsync().Result;
            //string alas = provider.Contents[0].ReadAsStringAsync().Result;

            //foreach (MultipartFileData file in provider.FileData)
            //{
            //    var one = file.Headers.ContentDisposition.FileName;
            //    var fileSize = file.Headers.ContentLength;
            //    var two = file.LocalFileName;
            //}

            // End 'Added' -----------

            var identifier = Guid.NewGuid().ToString("N").ToLowerInvariant();
            var mediaType = contentTypeHeader.MediaType;

            //var alasTwo = provider.Contents[1].ReadAsFormDataAsync().Result;

            //var stream = Request.Content.ReadAsStreamAsync().Result;
            var stream = provider.Contents[2].ReadAsStreamAsync().Result;

            
            var newPhoto = new Photo
            {
                Id = identifier,
                Name = identifier,
                Type = mediaType,
                Size = contentLength.Value
            };

            // Store metadata into database
            //DbContext.Photos.Add(photo);
            //DbContext.SaveChanges();

            //// Store photo streaming into file system
            PhotoDataStoreAccess.CreateAsync(
                identifier, stream);

            return Created(newPhoto);
        }

        [HttpPut]
        public IHttpActionResult Put([FromODataUri] string key, Photo photo)
        {
            if (photo == null)
            {
                return BadRequest();
            }

            try
            {
                var photoOriginal = new Photo(); //DbContext.Photos.Where(p => p.Id == key).FirstOrDefault();
                //photoOriginal.Size = photo.Size;
                //photoOriginal.Name = photo.Name;
                //photoOriginal.Type = photo.Type;

                //DbContext.SaveChanges();

                return Updated(photoOriginal);
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        public IHttpActionResult Patch([FromODataUri] string key, Delta<Photo> photoDelta)
        {
            if (photoDelta == null)
            {
                return BadRequest();
            }

            try
            {
                var photoOriginal = new Photo(); // DbContext.Photos.Where(p => p.Id == key).FirstOrDefault();
                //photoDelta.Patch(photoOriginal);
                //photoOriginal.Id = key;
                //DbContext.SaveChanges();
                return Updated(photoOriginal);
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        [HttpDelete]
        public IHttpActionResult Delete([FromODataUri] string key)
        {
            try
            {
                //var photoOriginal = DbContext.Photos.Where(p => p.Id == key).FirstOrDefault();
                //DbContext.Photos.Remove(photoOriginal);
                //DbContext.SaveChanges();
                return StatusCode(HttpStatusCode.NoContent);
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        [HttpGet]
        [ODataRoute("Photos({key})/$value")]
        public IHttpActionResult GetValue([FromODataUri] string key)
        {

            //var photoOriginal = DbContext.Photos.Where(p => p.Id == key).FirstOrDefault();
            //var photoStream = await PhotoDataStoreAccess.GetStreamAsync(key);
            var photoOriginal = new Photo();
            var photoStream = new MemoryStream();

            if (photoStream == null)
            {
                return NotFound();
            }

            var range = Request.Headers.Range;

            if (range == null)
            {
                // if the range header is present but null, then the header value must be invalid
                if (Request.Headers.Contains("Range"))
                {
                    return StatusCode(HttpStatusCode.RequestedRangeNotSatisfiable);
                }

                // if no range was requested, return the entire stream
                var response = Request.CreateResponse(HttpStatusCode.OK);

                response.Headers.AcceptRanges.Add("bytes");

                response.Content = new StreamContent(photoStream);
                response.Content.Headers.ContentType = MediaTypeHeaderValue.Parse(photoOriginal.Type);

                if (photoOriginal.Name != null)
                {
                    var contentDispositionHeader = new ContentDispositionHeaderValue("attachment")
                    {
                        FileName = photoOriginal.Name
                    };

                    response.Content.Headers.ContentDisposition = contentDispositionHeader;
                }

                return ResponseMessage(response);
            }
            else
            {
                if (!photoStream.CanSeek)
                {
                    return StatusCode(HttpStatusCode.NotImplemented);
                }

                var response = Request.CreateResponse(HttpStatusCode.PartialContent);
                response.Headers.AcceptRanges.Add("bytes");

                try
                {
                    // return the requested range(s)
                    response.Content = new ByteRangeStreamContent(photoStream, range, photoOriginal.Type);
                }
                catch (InvalidByteRangeException)
                {
                    response.Dispose();
                    throw;
                }

                if (photoOriginal.Name != null)
                {
                    var contentDispositionHeader = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                    {
                        FileName = photoOriginal.Name
                    };

                    response.Content.Headers.ContentDisposition = contentDispositionHeader;
                }

                // change status code if the entire stream was requested
                if (response.Content.Headers.ContentLength.Value == photoStream.Length)
                {
                    response.StatusCode = HttpStatusCode.OK;
                }

                return ResponseMessage(response);
            }
        }

        [HttpPut]
        [ODataRoute("Photos({key})/$value")]
        public IHttpActionResult PutValue([FromODataUri] string key)
        {
            try
            {
                var contentTypeHeader = Request.Content.Headers.ContentType;

                if (contentTypeHeader == null || contentTypeHeader.MediaType == null)
                {
                    return BadRequest();
                }

                var contentLength = Request.Content.Headers.ContentLength;

                if (!contentLength.HasValue)
                {
                    return StatusCode(HttpStatusCode.LengthRequired);
                }

                if (contentLength.Value <= 0)
                {
                    return BadRequest();
                }

                var stream = Request.Content.ReadAsStreamAsync();
                //PhotoDataStoreAccess.UpdateStreamAsync(
                //    key,
                //    stream);

                return StatusCode(HttpStatusCode.NoContent);
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        [HttpDelete]
        [ODataRoute("Photos({key})/$value")]
        // The logic should be same as Delete action
        public IHttpActionResult DeleteValue([FromODataUri] string key)
        {
            try
            {
                //var photoOriginal = DbContext.Photos.Where(p => p.Id == key).FirstOrDefault();
                //DbContext.Photos.Remove(photoOriginal);
                //DbContext.SaveChanges();
                return StatusCode(HttpStatusCode.NoContent);
            }
            catch (Exception)
            {
                return NotFound();
            }
        }

        protected override void Initialize(HttpControllerContext controllerContext)
        {
            base.Initialize(controllerContext);

            // Set the provider to create ODataStreamReferenceValue for stream value
            var provider = new DefaultMediaStreamReferenceProvider();
            var key = typeof(IMediaStreamReferenceProvider).FullName;
            Request.Properties[key] = provider;
        }
    }
}