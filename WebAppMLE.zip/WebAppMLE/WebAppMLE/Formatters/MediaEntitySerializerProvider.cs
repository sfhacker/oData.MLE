﻿
namespace WebAppMLE.Formatters
{
    using System.Web.OData.Formatter.Serialization;
    using Microsoft.OData.Edm;

    public class MediaEntitySerializerProvider : DefaultODataSerializerProvider
    {
        public override ODataEdmTypeSerializer GetEdmTypeSerializer(IEdmTypeReference edmType)
        {
            if (edmType.IsEntity())
            {
                return new MediaEntityTypeSerializer(this);
            }

            return base.GetEdmTypeSerializer(edmType);
        }
    }
}